<?php

$dictionary["IATI_Datasets"]["fields"]["iati_dataset_actions_changed_dataset"] = array(
  'name' => 'iati_dataset_actions_changed_dataset',
  'type' => 'link',
  'relationship' => 'iati_dataset_actions_changed_dataset',
  'source' => 'non-db',
  'module' => 'IATI_Dataset_Actions',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_IATI_DATASET_ACTIONS_CHANGED_DATASET_FROM_IATI_DATASET_ACTIONS_TITLE',
);
