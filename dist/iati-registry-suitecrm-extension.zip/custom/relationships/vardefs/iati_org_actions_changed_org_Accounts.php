<?php

$dictionary["Account"]["fields"]["iati_org_actions_changed_org"] = array(
  'name' => 'iati_org_actions_changed_org',
  'type' => 'link',
  'relationship' => 'iati_org_actions_changed_org',
  'source' => 'non-db',
  'module' => 'IATI_Organisation_Actions',
  'bean_name' => false,
  'side' => 'right',
  'vname' => '',
);
