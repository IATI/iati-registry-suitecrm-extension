<?php

$dictionary["Account"]["fields"]["iati_org_actions_changed_org"] = array(
  'name' => 'iati_org_actions_changed_org',
  'type' => 'link',
  'relationship' => 'iati_org_actions_changed_org',
  'source' => 'non-db',
  'module' => 'IATI_Organisation_Actions',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_IATI_ORGANISATION_ACTIONS_CHANGED_ORG_FROM_IATI_ORGANISATION_ACTIONS_TITLE',
);
