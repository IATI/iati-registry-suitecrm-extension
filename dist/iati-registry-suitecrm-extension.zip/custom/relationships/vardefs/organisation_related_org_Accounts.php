<?php

$dictionary["Account"]["fields"]["organisation_related_org"] = array(
  'name' => 'organisation_related_org',
  'type' => 'link',
  'relationship' => 'organisation_related_org',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'id_name' => 'LBL_ORGANISATION_RELATED_ORG_L_TITLE',
);
$dictionary["Account"]["fields"]["organisation_related_org"] = array(
  'name' => 'organisation_related_org',
  'type' => 'link',
  'relationship' => 'organisation_related_org',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'id_name' => 'LBL_ORGANISATION_RELATED_ORG_R_TITLE',
);
