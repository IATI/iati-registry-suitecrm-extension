<?php

$dictionary["Contact"]["fields"]["iati_org_actions_actor_person"] = array(
  'name' => 'iati_org_actions_actor_person',
  'type' => 'link',
  'relationship' => 'iati_org_actions_actor_person',
  'source' => 'non-db',
  'module' => 'IATI_Organisation_Actions',
  'bean_name' => false,
  'side' => 'right',
  'vname' => '',
);
