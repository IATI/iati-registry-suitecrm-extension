<?php

$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Organisations';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'People';
