<?php

$mod_strings['LBL_FP_EVENTS_CONTACTS_FROM_CONTACTS_TITLE'] = 'People';
