<?php
class ToolButtonsHook{
    function test($bean, $event, $args){
        LoggerManager::getLogger()->warn($event);
        LoggerManager::getLogger()->warn($args);
        LoggerManager::getLogger()->warn($bean);
    }
}
