<?php

$mod_strings['LBL_AM_PROJECTTEMPLATES_CONTACTS_1_TITLE'] = 'People';
