<?php

$mod_strings['LBL_CONTACT'] = 'Person';
