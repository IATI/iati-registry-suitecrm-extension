<?php

$mod_strings['LBL_CONTACTS_SYNC'] = 'Person Sync';
