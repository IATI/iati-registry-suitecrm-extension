<?php

$mod_strings['LBL_CONTACT_NAME'] = 'Person:';
$mod_strings['LBL_LIST_CONTACT_NAME'] = 'Person';
$mod_strings['LBL_ACCOUNTS'] = 'Organisations';
$mod_strings['LBL_CONTACT_ID'] = 'Person ID:';
$mod_strings['LBL_LIST_CONTACT'] = 'Person';
$mod_strings['LBL_ACCOUNT_ID'] = 'Organisation ID:';
