<?php

$mod_strings['LBL_ACCOUNT_NAME'] = 'Organisation Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Organisation ID';
$mod_strings['LBL_CONTACT_CREATED_BY_NAME'] = 'Created by contact';
$mod_strings['LBL_CONTACT_CREATED_BY'] = 'Created by';
$mod_strings['LBL_CONTACTS'] = 'People';
$mod_strings['LBL_ACCOUNT'] = 'Organisation';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'People';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Organisation Name';
