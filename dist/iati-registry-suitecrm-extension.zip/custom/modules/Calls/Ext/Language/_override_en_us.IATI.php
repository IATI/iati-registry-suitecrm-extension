<?php

$mod_strings['LBL_CONTACT_NAME'] = 'Person:';
$mod_strings['LBL_ACCOUNT'] = 'Organisation';
$mod_strings['LBL_CONTACTS'] = 'People';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'People';
$mod_strings['LBL_LIST_CONTACT'] = 'Person';
