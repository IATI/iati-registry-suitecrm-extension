<?php

$mod_strings['LBL_ACCOUNTS'] = 'Organisations';
$mod_strings['LBL_CONTACTS'] = 'People';
