<?php

$mod_strings['LBL_CONTACTS'] = 'People';
$mod_strings['LBL_ACCOUNTS'] = 'Organisations';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'People';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Organisations';
