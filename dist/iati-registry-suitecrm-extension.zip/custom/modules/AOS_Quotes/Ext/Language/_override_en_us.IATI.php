<?php

$mod_strings['LBL_BILLING_ACCOUNT'] = 'Organisation';
$mod_strings['LBL_BILLING_CONTACT'] = 'Person';
$mod_strings['LBL_ACCOUNTS'] = 'Organisations';
$mod_strings['LBL_CONTACTS'] = 'People';
