<?php

$mod_strings['LBL_REPORTS_TO'] = 'Reports To:';
$mod_strings['LBL_CONTACTS'] = 'People';
$mod_strings['LBL_ACCOUNT'] = 'Organisation';
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_CONTACT_ID'] = 'Person ID';
$mod_strings['LBL_CONVERTED_CONTACT'] = 'Converted Person:';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Organisation Description';
$mod_strings['LBL_ACCOUNT_ID'] = 'Organisation ID';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Organisation Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Organisation Name';
$mod_strings['LBL_CONVERTED_ACCOUNT'] = 'Converted Organisation:';
$mod_strings['LNK_SELECT_ACCOUNTS'] = ' OR Select Organisation';
$mod_strings['LNK_NEW_ACCOUNT'] = 'Create Organisation';
