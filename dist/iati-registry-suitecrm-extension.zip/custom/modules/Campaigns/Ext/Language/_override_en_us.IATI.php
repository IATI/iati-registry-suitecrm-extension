<?php

$mod_strings['LBL_CONTACTS'] = 'People';
$mod_strings['LBL_ACCOUNTS'] = 'Organisations';
$mod_strings['LBL_CAMPAIGN_ACCOUNTS_SUBPANEL_TITLE'] = 'Organisations';
$mod_strings['LBL_LOG_ENTRIES_CONTACT_TITLE'] = 'People Created';
