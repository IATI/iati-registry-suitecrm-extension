<?php

$mod_strings['LBL_CONTACTS_SYNC'] = 'People Sync';
